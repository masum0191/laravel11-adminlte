<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Permissions extends Model
{
    protected $fillable = [
      'guard_name',  'name', 
    ];
    
}
