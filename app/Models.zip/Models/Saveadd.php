<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Saveadd extends Model
{
    protected $fillable=['user_id','bikesale_id'];
}
